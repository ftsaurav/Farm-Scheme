import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="register-container">
      <div class="register-card">
        <div class="logo">🌾 Farm-Scheme</div>
        <h2>Create Account</h2>
        <p class="subtitle">Join our farming community today</p>

        @if (errorMessage()) {
          <div class="alert alert-error">{{ errorMessage() }}</div>
        }

        @if (successMessage()) {
          <div class="alert alert-success">{{ successMessage() }}</div>
        }

        @if (!userType()) {
          <div class="user-type-selection">
            <h3>Select User Type</h3>
            <div class="type-buttons">
              <button (click)="selectUserType('farmer')" class="type-btn">
                <span class="type-icon">🌾</span>
                <span class="type-label">Farmer</span>
              </button>
              <button (click)="selectUserType('bidder')" class="type-btn">
                <span class="type-icon">💼</span>
                <span class="type-label">Bidder</span>
              </button>
            </div>
          </div>
        } @else {
          <form (ngSubmit)="onSubmit()" class="register-form">
            <div class="form-section">
              <h3>Personal Details</h3>
              <div class="form-row">
                <div class="form-group">
                  <label>Full Name *</label>
                  <input type="text" [(ngModel)]="formData.fullName" name="fullName" required />
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>Contact Number *</label>
                  <input type="tel" [(ngModel)]="formData.contactNo" name="contactNo" required />
                </div>
                <div class="form-group">
                  <label>Email Address *</label>
                  <input type="email" [(ngModel)]="formData.email" name="email" required />
                </div>
              </div>
            </div>

            <div class="form-section">
              <h3>Address Details</h3>
              <div class="form-group">
                <label>Address Line 1 *</label>
                <input type="text" [(ngModel)]="formData.addressLine1" name="addressLine1" required />
              </div>
              <div class="form-group">
                <label>Address Line 2</label>
                <input type="text" [(ngModel)]="formData.addressLine2" name="addressLine2" />
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>City *</label>
                  <input type="text" [(ngModel)]="formData.city" name="city" required />
                </div>
                <div class="form-group">
                  <label>State *</label>
                  <input type="text" [(ngModel)]="formData.state" name="state" required />
                </div>
                <div class="form-group">
                  <label>Pin Code *</label>
                  <input type="text" [(ngModel)]="formData.pincode" name="pincode" required />
                </div>
              </div>
            </div>

            @if (userType() === 'farmer') {
              <div class="form-section">
                <h3>Land Details</h3>
                <div class="form-row">
                  <div class="form-group">
                    <label>Area (in Hectares) *</label>
                    <input type="number" [(ngModel)]="formData.landArea" name="landArea" required />
                  </div>
                  <div class="form-group">
                    <label>Land Pin Code *</label>
                    <input type="text" [(ngModel)]="formData.landPincode" name="landPincode" required />
                  </div>
                </div>
                <div class="form-group">
                  <label>Land Address *</label>
                  <input type="text" [(ngModel)]="formData.landAddress" name="landAddress" required />
                </div>
              </div>
            }

            <div class="form-section">
              <h3>Bank Details</h3>
              <div class="form-row">
                <div class="form-group">
                  <label>Account Number *</label>
                  <input type="text" [(ngModel)]="formData.accountNo" name="accountNo" required />
                </div>
                <div class="form-group">
                  <label>IFSC Code *</label>
                  <input type="text" [(ngModel)]="formData.ifscCode" name="ifscCode" required />
                </div>
              </div>
            </div>

            <div class="form-section">
  <h3>Government Details</h3>

  <div class="form-row">
    <div class="form-group">
      <label>Aadhaar Number *</label>
      <input
        type="text"
        [(ngModel)]="formData.aadhaarNo"
        name="aadhaarNo"
        required
      />
    </div>

    <div class="form-group">
      <label>PAN Number *</label>
      <input
        type="text"
        [(ngModel)]="formData.panNo"
        name="panNo"
        required
      />
    </div>
  </div>

  <!-- Farmer Field -->
  @if (userType() === 'farmer') {
    <div class="form-group">
      <label>Plot Number *</label>
      <input
        type="text"
        [(ngModel)]="formData.plotNo"
        name="plotNo"
        required
      />
    </div>
  }

  <!-- Bidder Field -->
  @if (userType() === 'bidder') {
    <div class="form-group">
      <label>Trading License Number *</label>
      <input
        type="text"
        [(ngModel)]="formData.tradingLicenseNo"
        name="tradingNo"
        required
      />
    </div>
  }

</div>

            <div class="form-section">
              <h3>Account Security</h3>
              <div class="form-row">
                <div class="form-group">
                  <label>Password *</label>
                  <input type="password" [(ngModel)]="formData.password" name="password" required />
                </div>
                <div class="form-group">
                  <label>Confirm Password *</label>
                  <input type="password" [(ngModel)]="formData.confirmPassword" name="confirmPassword" required />
                </div>
              </div>
            </div>

            <div class="form-actions">
              <button type="button" (click)="resetForm()" class="btn btn-secondary">Reset</button>
              <button type="submit" class="btn btn-primary" [disabled]="loading()">
                @if (loading()) {
                  <span class="spinner"></span>
                } @else {
                  Register
                }
              </button>
            </div>
          </form>
        }

        <div class="login-link">
          <p>Already have an account? <a routerLink="/login" class="link">Login Here</a></p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .register-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      padding: 2rem;
    }

    .register-card {
      max-width: 800px;
      margin: 0 auto;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
      backdrop-filter: blur(10px);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 24px;
      padding: 3rem;
      animation: fadeInUp 0.6s ease-out;
    }

    .logo {
      font-size: 2rem;
      font-weight: 700;
      text-align: center;
      background: linear-gradient(135deg, #10b981, #34d399);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 1rem;
    }

    h2 {
      color: #fff;
      text-align: center;
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }

    .subtitle {
      color: #cbd5e1;
      text-align: center;
      margin-bottom: 2rem;
    }

    .alert {
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
      animation: slideIn 0.3s ease-out;
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #fca5a5;
    }

    .alert-success {
      background: rgba(16, 185, 129, 0.1);
      border: 1px solid rgba(16, 185, 129, 0.3);
      color: #6ee7b7;
    }

    .user-type-selection {
      text-align: center;
      padding: 2rem 0;
    }

    .user-type-selection h3 {
      color: #10b981;
      margin-bottom: 2rem;
      font-size: 1.5rem;
    }

    .type-buttons {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 2rem;
    }

    .type-btn {
      padding: 3rem 2rem;
      background: rgba(15, 23, 42, 0.5);
      border: 2px solid rgba(16, 185, 129, 0.3);
      border-radius: 20px;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 1rem;
    }

    .type-btn:hover {
      transform: translateY(-5px);
      border-color: #10b981;
      box-shadow: 0 10px 40px rgba(16, 185, 129, 0.3);
    }

    .type-icon {
      font-size: 4rem;
    }

    .type-label {
      color: #fff;
      font-size: 1.25rem;
      font-weight: 600;
    }

    .form-section {
      margin-bottom: 2rem;
      padding-bottom: 2rem;
      border-bottom: 1px solid rgba(16, 185, 129, 0.2);
    }

    .form-section:last-of-type {
      border-bottom: none;
    }

    .form-section h3 {
      color: #10b981;
      margin-bottom: 1.5rem;
      font-size: 1.25rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 1rem;
    }

    .form-group {
      margin-bottom: 1rem;
    }

    .form-group label {
      display: block;
      color: #cbd5e1;
      font-weight: 600;
      margin-bottom: 0.5rem;
      font-size: 0.875rem;
    }

    .form-group input,
    .form-group select {
      width: 100%;
      padding: 0.875rem;
      background: rgba(15, 23, 42, 0.5);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      color: white;
      font-size: 0.875rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus {
      outline: none;
      border-color: #10b981;
      box-shadow: 0 0 20px rgba(16, 185, 129, 0.3);
    }

    .form-actions {
      display: flex;
      gap: 1rem;
      margin-top: 2rem;
    }

    .btn {
      flex: 1;
      padding: 1rem;
      border: none;
      border-radius: 12px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
    }

    .btn-primary {
      background: linear-gradient(135deg, #10b981, #059669);
      color: white;
      box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
    }

    .btn-primary:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 6px 30px rgba(16, 185, 129, 0.6);
    }

    .btn-secondary {
      background: rgba(255, 255, 255, 0.1);
      color: white;
      border: 2px solid #10b981;
    }

    .btn-secondary:hover {
      background: rgba(16, 185, 129, 0.2);
    }

    .btn-primary:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255, 255, 255, 0.3);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    .login-link {
      margin-top: 2rem;
      text-align: center;
      color: #cbd5e1;
    }

    .link {
      color: #10b981;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .link:hover {
      color: #34d399;
      text-decoration: underline;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(-20px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }
  `]
})
export class RegisterComponent {
  userType = signal<'farmer' | 'bidder' | null>(null);
  loading = signal(false);
  errorMessage = signal('');
  successMessage = signal('');

  formData: any = {
  fullName: '',
  contactNo: '',
  email: '',
  addressLine1: '',
  addressLine2: '',
  city: '',
  state: '',
  pincode: '',

  landArea: '',
  landAddress: '',
  landPincode: '',

  accountNo: '',
  ifscCode: '',

  aadhaarNo: '',
  panNo: '',
  plotNo: '',
  tradingLicenseNo: '',

  password: '',
  confirmPassword: ''
};
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  selectUserType(type: 'farmer' | 'bidder') {
    this.userType.set(type);
  }

  onFileChange(event: any, documentType: string) {
    const file = event.target.files[0];
    if (file) {
      this.formData.documents[documentType] = file;
    }
  }

 async onSubmit() {
  this.errorMessage.set('');
  this.successMessage.set('');

  if (this.formData.password !== this.formData.confirmPassword) {
    this.errorMessage.set('Passwords do not match');
    return;
  }

  this.loading.set(true);

  const payload = {
    ...this.formData,
    userType: this.userType()
  };

  const result = await this.authService.register(payload);

  this.loading.set(false);

  if (result.success) {
    this.successMessage.set(result.message || 'Registration successful!');
    setTimeout(() => {
      this.router.navigate(['/login']);
    }, 2000);
  } else {
    this.errorMessage.set(result.message || 'Registration failed');
  }
}
  resetForm() {
  this.formData = {
    fullName: '',
    contactNo: '',
    email: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    pincode: '',

    landArea: '',
    landAddress: '',
    landPincode: '',

    accountNo: '',
    ifscCode: '',

    aadhaarNo: '',
    panNo: '',
    plotNo: '',
    tradingLicenseNo: '',

    password: '',
    confirmPassword: ''
  };
}
}
