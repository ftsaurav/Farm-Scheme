import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="login-container">
      <div class="login-card">
        <div class="logo">🌾 Farm-Scheme</div>
        <h2>Welcome Back</h2>
        <p class="subtitle">Sign in to continue to your account</p>

        @if (errorMessage()) {
          <div class="alert alert-error">{{ errorMessage() }}</div>
        }

        <form (ngSubmit)="onSubmit()" class="login-form">
          <div class="form-group">
            <label>Email Address</label>
            <input
              type="email"
              [(ngModel)]="email"
              name="email"
              placeholder="Enter your email"
              required
            />
          </div>

          <div class="form-group">
            <label>Password</label>
            <input
              type="password"
              [(ngModel)]="password"
              name="password"
              placeholder="Enter your password"
              required
            />
          </div>

          <div class="forgot-password">
            <a href="#" class="link">Forgot Password?</a>
          </div>

          <button type="submit" class="btn btn-primary" [disabled]="loading()">
            @if (loading()) {
              <span class="spinner"></span>
            } @else {
              Login
            }
          </button>
        </form>

        <div class="register-link">
          <p>New User? <a routerLink="/register" class="link">Register Here</a></p>
        </div>

        <div class="user-types">
          <p>Are you a Farmer or Bidder?</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .login-container {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      padding: 2rem;
    }

    .login-card {
      width: 100%;
      max-width: 450px;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
      backdrop-filter: blur(10px);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 24px;
      padding: 3rem;
      animation: fadeInUp 0.6s ease-out;
    }

    .logo {
      font-size: 2rem;
      font-weight: 700;
      text-align: center;
      background: linear-gradient(135deg, #10b981, #34d399);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 1rem;
    }

    h2 {
      color: #fff;
      text-align: center;
      font-size: 2rem;
      margin-bottom: 0.5rem;
    }

    .subtitle {
      color: #cbd5e1;
      text-align: center;
      margin-bottom: 2rem;
    }

    .alert {
      padding: 1rem;
      border-radius: 12px;
      margin-bottom: 1.5rem;
      animation: slideIn 0.3s ease-out;
    }

    .alert-error {
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      color: #fca5a5;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      color: #10b981;
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    .form-group input {
      width: 100%;
      padding: 1rem;
      background: rgba(15, 23, 42, 0.5);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      color: white;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus {
      outline: none;
      border-color: #10b981;
      box-shadow: 0 0 20px rgba(16, 185, 129, 0.3);
    }

    .forgot-password {
      text-align: right;
      margin-bottom: 1.5rem;
    }

    .link {
      color: #10b981;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
    }

    .link:hover {
      color: #34d399;
      text-decoration: underline;
    }

    .btn {
      width: 100%;
      padding: 1rem;
      border: none;
      border-radius: 12px;
      font-weight: 600;
      font-size: 1rem;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
    }

    .btn-primary {
      background: linear-gradient(135deg, #10b981, #059669);
      color: white;
      box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
    }

    .btn-primary:hover:not(:disabled) {
      transform: translateY(-2px);
      box-shadow: 0 6px 30px rgba(16, 185, 129, 0.6);
    }

    .btn-primary:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 3px solid rgba(255, 255, 255, 0.3);
      border-top-color: white;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }

    .register-link {
      margin-top: 2rem;
      text-align: center;
      color: #cbd5e1;
    }

    .user-types {
      margin-top: 2rem;
      padding-top: 2rem;
      border-top: 1px solid rgba(16, 185, 129, 0.2);
      text-align: center;
      color: #94a3b8;
      font-size: 0.875rem;
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes slideIn {
      from {
        opacity: 0;
        transform: translateX(-20px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes spin {
      to {
        transform: rotate(360deg);
      }
    }
  `]
})
export class LoginComponent {
  email = '';
  password = '';
  loading = signal(false);
  errorMessage = signal('');

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  async onSubmit() {
    this.errorMessage.set('');

    if (!this.email || !this.password) {
      this.errorMessage.set('Please fill in all fields');
      return;
    }

    this.loading.set(true);

    const result = await this.authService.login(this.email, this.password);

    this.loading.set(false);

    if (!result.success) {
      this.errorMessage.set(result.message || 'Login failed');
    }
  }
}
