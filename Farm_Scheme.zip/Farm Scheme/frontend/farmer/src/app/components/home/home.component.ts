import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="home-container">
      <nav class="navbar">
        <div class="nav-logo">
          <h1>🌾 Farm-Scheme</h1>
        </div>
        <div class="nav-links">
          <a href="#home" class="nav-link">Home</a>
          <a href="#about" class="nav-link">About Us</a>
          <a routerLink="/login" class="nav-link">Login</a>
          <a href="#contact" class="nav-link">Contact</a>
        </div>
      </nav>

      <section id="home" class="hero-section">
        <div class="hero-content">
          <h1 class="hero-title">Empowering Farmers Through Digital Innovation</h1>
          <p class="hero-subtitle">Connecting farmers with fair prices through transparent bidding and comprehensive crop insurance</p>
          <div class="hero-buttons">
            <button class="btn btn-primary" routerLink="/register">Get Started</button>
            <button class="btn btn-secondary" routerLink="/login">Sign In</button>
          </div>
        </div>
        <div class="hero-image">
          <div class="floating-card card-1">
            <span class="icon">💰</span>
            <h3>Fair Bidding</h3>
            <p>Get the best price for your crops</p>
          </div>
          <div class="floating-card card-2">
            <span class="icon">🛡️</span>
            <h3>Crop Insurance</h3>
            <p>Protect your harvest from losses</p>
          </div>
          <div class="floating-card card-3">
            <span class="icon">📊</span>
            <h3>Market Insights</h3>
            <p>Real-time market analytics</p>
          </div>
        </div>
      </section>

      <section id="about" class="about-section">
        <div class="container">
          <h2 class="section-title">About Farm-Scheme</h2>
          <div class="about-grid">
            <div class="about-card">
              <div class="card-icon">🌱</div>
              <h3>For Farmers</h3>
              <p>List your crops for auction, get competitive bids from multiple buyers, and secure fair prices. Access government schemes and crop insurance programs easily.</p>
            </div>
            <div class="about-card">
              <div class="card-icon">🤝</div>
              <h3>For Bidders</h3>
              <p>Access a wide variety of quality crops directly from farmers. Participate in transparent bidding processes and build direct relationships with producers.</p>
            </div>
            <div class="about-card">
              <div class="card-icon">🔒</div>
              <h3>Secure & Transparent</h3>
              <p>Admin-controlled approval process ensures quality and fairness. All transactions are tracked and documented for complete transparency.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="features" class="features-section">
        <div class="container">
          <h2 class="section-title">Key Features</h2>
          <div class="features-grid">
            <div class="feature-item">
              <div class="feature-number">01</div>
              <h3>Crop Bidding Platform</h3>
              <p>Farmers can list crops with quantity and quality certificates. Bidders compete for the best prices in real-time.</p>
            </div>
            <div class="feature-item">
              <div class="feature-number">02</div>
              <h3>Fasal Bima Yojna</h3>
              <p>Apply for government crop insurance schemes. Low premium rates: 2% for Kharif, 1.5% for Rabi crops.</p>
            </div>
            <div class="feature-item">
              <div class="feature-number">03</div>
              <h3>Insurance Calculator</h3>
              <p>Calculate premiums based on season, crop type, and area. Get instant quotes before applying.</p>
            </div>
            <div class="feature-item">
              <div class="feature-number">04</div>
              <h3>Transaction History</h3>
              <p>Track all your sales, bids, and insurance claims in one place. Download reports anytime.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="contact" class="contact-section">
        <div class="container">
          <h2 class="section-title">Get In Touch</h2>
          <div class="contact-form-container">
            <form class="contact-form">
              <div class="form-group">
                <label>Your Name</label>
                <input type="text" placeholder="Enter your name" />
              </div>
              <div class="form-group">
                <label>Email Address</label>
                <input type="email" placeholder="Enter your email" />
              </div>
              <div class="form-group">
                <label>Message</label>
                <textarea rows="5" placeholder="Your message"></textarea>
              </div>
              <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
          </div>
        </div>
      </section>

      <footer class="footer">
        <div class="container">
          <p>&copy; 2025 Farm-Scheme. Empowering farmers across India.</p>
        </div>
      </footer>
    </div>
  `,
  styles: [`
    .home-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
      color: #fff;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1.5rem 3rem;
      background: rgba(15, 23, 42, 0.8);
      backdrop-filter: blur(10px);
      position: sticky;
      top: 0;
      z-index: 100;
      border-bottom: 1px solid rgba(16, 185, 129, 0.2);
    }

    .nav-logo h1 {
      font-size: 1.5rem;
      font-weight: 700;
      background: linear-gradient(135deg, #10b981, #34d399);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .nav-links {
      display: flex;
      gap: 2rem;
    }

    .nav-link {
      color: #e2e8f0;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s ease;
      position: relative;
    }

    .nav-link::after {
      content: '';
      position: absolute;
      bottom: -5px;
      left: 0;
      width: 0;
      height: 2px;
      background: #10b981;
      transition: width 0.3s ease;
    }

    .nav-link:hover {
      color: #10b981;
    }

    .nav-link:hover::after {
      width: 100%;
    }

    .hero-section {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 4rem;
      padding: 6rem 3rem;
      align-items: center;
      min-height: 80vh;
    }

    .hero-content {
      animation: fadeInLeft 1s ease-out;
    }

    .hero-title {
      font-size: 3.5rem;
      font-weight: 800;
      line-height: 1.2;
      margin-bottom: 1.5rem;
      background: linear-gradient(135deg, #fff, #10b981);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .hero-subtitle {
      font-size: 1.25rem;
      color: #cbd5e1;
      margin-bottom: 2rem;
      line-height: 1.6;
    }

    .hero-buttons {
      display: flex;
      gap: 1rem;
    }

    .btn {
      padding: 1rem 2rem;
      border-radius: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      border: none;
      font-size: 1rem;
    }

    .btn-primary {
      background: linear-gradient(135deg, #10b981, #059669);
      color: white;
      box-shadow: 0 4px 20px rgba(16, 185, 129, 0.4);
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 30px rgba(16, 185, 129, 0.6);
    }

    .btn-secondary {
      background: rgba(255, 255, 255, 0.1);
      color: white;
      border: 2px solid #10b981;
    }

    .btn-secondary:hover {
      background: rgba(16, 185, 129, 0.2);
      transform: translateY(-2px);
    }

    .hero-image {
      position: relative;
      height: 500px;
      animation: fadeInRight 1s ease-out;
    }

    .floating-card {
      position: absolute;
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.1));
      backdrop-filter: blur(10px);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 20px;
      padding: 2rem;
      animation: float 3s ease-in-out infinite;
    }

    .floating-card .icon {
      font-size: 3rem;
      display: block;
      margin-bottom: 1rem;
    }

    .floating-card h3 {
      color: #10b981;
      margin-bottom: 0.5rem;
      font-size: 1.25rem;
    }

    .floating-card p {
      color: #cbd5e1;
      font-size: 0.875rem;
    }

    .card-1 {
      top: 50px;
      left: 50px;
      animation-delay: 0s;
    }

    .card-2 {
      top: 200px;
      right: 50px;
      animation-delay: 1s;
    }

    .card-3 {
      bottom: 50px;
      left: 100px;
      animation-delay: 2s;
    }

    .about-section, .features-section, .contact-section {
      padding: 6rem 3rem;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .section-title {
      text-align: center;
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 3rem;
      background: linear-gradient(135deg, #fff, #10b981);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }

    .about-grid, .features-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 2rem;
    }

    .about-card {
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
      border: 1px solid rgba(16, 185, 129, 0.2);
      border-radius: 20px;
      padding: 2rem;
      transition: all 0.3s ease;
      animation: fadeInUp 1s ease-out;
    }

    .about-card:hover {
      transform: translateY(-10px);
      border-color: #10b981;
      box-shadow: 0 10px 40px rgba(16, 185, 129, 0.3);
    }

    .card-icon {
      font-size: 3rem;
      margin-bottom: 1rem;
    }

    .about-card h3 {
      color: #10b981;
      font-size: 1.5rem;
      margin-bottom: 1rem;
    }

    .about-card p {
      color: #cbd5e1;
      line-height: 1.6;
    }

    .feature-item {
      position: relative;
      padding-left: 5rem;
      animation: fadeInUp 1s ease-out;
    }

    .feature-number {
      position: absolute;
      left: 0;
      top: 0;
      font-size: 3rem;
      font-weight: 800;
      color: rgba(16, 185, 129, 0.2);
    }

    .feature-item h3 {
      color: #10b981;
      font-size: 1.5rem;
      margin-bottom: 0.5rem;
    }

    .feature-item p {
      color: #cbd5e1;
      line-height: 1.6;
    }

    .contact-form-container {
      max-width: 600px;
      margin: 0 auto;
    }

    .contact-form {
      background: linear-gradient(135deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
      border: 1px solid rgba(16, 185, 129, 0.2);
      border-radius: 20px;
      padding: 3rem;
    }

    .form-group {
      margin-bottom: 1.5rem;
    }

    .form-group label {
      display: block;
      color: #10b981;
      font-weight: 600;
      margin-bottom: 0.5rem;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 1rem;
      background: rgba(15, 23, 42, 0.5);
      border: 1px solid rgba(16, 185, 129, 0.3);
      border-radius: 12px;
      color: white;
      font-size: 1rem;
      transition: all 0.3s ease;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #10b981;
      box-shadow: 0 0 20px rgba(16, 185, 129, 0.3);
    }

    .footer {
      background: rgba(15, 23, 42, 0.8);
      border-top: 1px solid rgba(16, 185, 129, 0.2);
      padding: 2rem 3rem;
      text-align: center;
      color: #cbd5e1;
    }

    @keyframes fadeInLeft {
      from {
        opacity: 0;
        transform: translateX(-50px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes fadeInRight {
      from {
        opacity: 0;
        transform: translateX(50px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes float {
      0%, 100% {
        transform: translateY(0);
      }
      50% {
        transform: translateY(-20px);
      }
    }

    @media (max-width: 768px) {
      .hero-section {
        grid-template-columns: 1fr;
        padding: 3rem 1.5rem;
      }

      .hero-title {
        font-size: 2.5rem;
      }

      .nav-links {
        gap: 1rem;
      }

      .navbar {
        padding: 1rem 1.5rem;
      }
    }
  `]
})
export class HomeComponent {}
