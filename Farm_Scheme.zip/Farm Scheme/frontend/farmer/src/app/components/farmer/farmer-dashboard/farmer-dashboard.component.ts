import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-farmer-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterOutlet],
  template: `
    <div class="dashboard-container">
      <nav class="sidebar">
        <div class="sidebar-header">
          <h1>🌾 Farm-Scheme</h1>
          <p class="user-name">{{ authService.currentUser()?.name }}</p>
        </div>
        <div class="sidebar-menu">
          <a routerLink="/farmer/bidding" routerLinkActive="active" class="menu-item">
            <span class="icon">💰</span>
            <span>Bidding</span>
          </a>
          <a routerLink="/farmer/insurance" routerLinkActive="active" class="menu-item">
            <span class="icon">🛡️</span>
            <span>Insurance</span>
          </a>
        </div>
        <button (click)="logout()" class="logout-btn">
          <span class="icon">🚪</span>
          <span>Logout</span>
        </button>
      </nav>
      <div class="main-content">
        <router-outlet></router-outlet>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container {
      display: grid;
      grid-template-columns: 280px 1fr;
      min-height: 100vh;
      background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    }

    .sidebar {
      background: linear-gradient(180deg, rgba(16, 185, 129, 0.1), rgba(52, 211, 153, 0.05));
      border-right: 1px solid rgba(16, 185, 129, 0.3);
      display: flex;
      flex-direction: column;
      padding: 2rem 0;
    }

    .sidebar-header {
      padding: 0 2rem 2rem;
      border-bottom: 1px solid rgba(16, 185, 129, 0.2);
      margin-bottom: 2rem;
    }

    .sidebar-header h1 {
      font-size: 1.5rem;
      background: linear-gradient(135deg, #10b981, #34d399);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
      margin-bottom: 0.5rem;
    }

    .user-name {
      color: #cbd5e1;
      font-size: 0.875rem;
    }

    .sidebar-menu {
      flex: 1;
    }

    .menu-item {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1rem 2rem;
      color: #cbd5e1;
      text-decoration: none;
      transition: all 0.3s ease;
      border-left: 3px solid transparent;
    }

    .menu-item:hover {
      background: rgba(16, 185, 129, 0.1);
      color: #10b981;
      border-left-color: #10b981;
    }

    .menu-item.active {
      background: rgba(16, 185, 129, 0.2);
      color: #10b981;
      border-left-color: #10b981;
      font-weight: 600;
    }

    .menu-item .icon {
      font-size: 1.25rem;
    }

    .logout-btn {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 1rem 2rem;
      margin: 0 1rem;
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.3);
      border-radius: 12px;
      color: #fca5a5;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .logout-btn:hover {
      background: rgba(239, 68, 68, 0.2);
      transform: translateY(-2px);
    }

    .main-content {
      padding: 2rem;
      overflow-y: auto;
    }

    @media (max-width: 768px) {
      .dashboard-container {
        grid-template-columns: 1fr;
      }

      .sidebar {
        display: none;
      }
    }
  `]
})
export class FarmerDashboardComponent {
  constructor(
    public authService: AuthService,
    private router: Router
  ) {}

  logout() {
    this.authService.logout();
  }
}
