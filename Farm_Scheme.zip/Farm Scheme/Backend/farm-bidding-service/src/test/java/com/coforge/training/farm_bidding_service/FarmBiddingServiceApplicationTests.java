package com.coforge.training.farm_bidding_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmBiddingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
