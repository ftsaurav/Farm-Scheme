package com.coforge.training.farm_bidding_service.repository;

import com.coforge.training.farm_bidding_service.entity.Bid;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface BidRepository extends JpaRepository<Bid, Long> {

    List<Bid> findByCropId(Long cropId);

    Optional<Bid> findTopByCropIdOrderByBidAmountDesc(Long cropId);


    long countByBidderId(Long bidderId);

    @Query("SELECT COUNT(b) FROM Bid b WHERE b.bidderId = :bidderId AND b.status = 'ACTIVE'")
    long countActiveBids(Long bidderId);

    @Query("SELECT COUNT(b) FROM Bid b WHERE b.bidderId = :bidderId AND b.status = 'WON'")
    long countWonAuctions(Long bidderId);

    @Query("SELECT COALESCE(SUM(b.bidAmount),0) FROM Bid b WHERE b.bidderId = :bidderId AND b.status = 'WON'")
    Double totalSpent(Long bidderId);



}