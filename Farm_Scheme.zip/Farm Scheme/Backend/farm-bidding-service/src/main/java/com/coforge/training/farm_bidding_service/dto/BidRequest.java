package com.coforge.training.farm_bidding_service.dto;

import lombok.Data;

@Data
public class BidRequest {

    private Long cropId;

    private Long bidderId;

    private Double bidAmount;

}