package com.coforge.training.farm_bidding_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long cropId;

    private Long bidderId;

    private Double bidAmount;

    private LocalDateTime bidTime;

    private String status;
    // ACTIVE
    // WON
    // LOST
}