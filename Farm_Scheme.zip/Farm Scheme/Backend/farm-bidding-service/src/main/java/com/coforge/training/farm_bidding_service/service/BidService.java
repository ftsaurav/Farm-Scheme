package com.coforge.training.farm_bidding_service.service;

import com.coforge.training.farm_bidding_service.dto.BidRequest;
import com.coforge.training.farm_bidding_service.entity.Auction;
import com.coforge.training.farm_bidding_service.entity.Bid;
import com.coforge.training.farm_bidding_service.exception.BidException;
import com.coforge.training.farm_bidding_service.repository.AuctionRepository;
import com.coforge.training.farm_bidding_service.repository.BidRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class BidService {

    private final BidRepository bidRepository;
    private final AuctionRepository auctionRepository;

    public Bid placeBid(BidRequest request) {

        Auction auction = auctionRepository
                .findByCropIdAndClosedFalse(request.getCropId())
                .orElseThrow(() -> new RuntimeException("Active auction not found"));

        LocalDateTime now = LocalDateTime.now();

        if (now.isBefore(auction.getStartTime())) {
            throw new BidException("Auction not started yet");
        }

        if (now.isAfter(auction.getEndTime()) || auction.isClosed()) {
            throw new BidException("Auction already closed");
        }

        Optional<Bid> highestBid =
                bidRepository.findTopByCropIdOrderByBidAmountDesc(request.getCropId());

        if (highestBid.isPresent()) {

            if (request.getBidAmount() <= highestBid.get().getBidAmount()) {
                throw new BidException("Bid must be higher than current highest bid");
            }
        }

        Bid bid = Bid.builder()
                .cropId(request.getCropId())
                .bidderId(request.getBidderId())
                .bidAmount(request.getBidAmount())
                .bidTime(LocalDateTime.now())
                .status("ACTIVE")
                .build();

        return bidRepository.save(bid);
    }

    public List<Bid> getBids(Long cropId) {
        return bidRepository.findByCropId(cropId);
    }

    public Bid getHighestBid(Long cropId) {
        return bidRepository
                .findTopByCropIdOrderByBidAmountDesc(cropId)
                .orElse(null);
    }

    public Bid getAuctionWinner(Long cropId) {

        return bidRepository
                .findTopByCropIdOrderByBidAmountDesc(cropId)
                .orElseThrow(() ->
                        new BidException("No bids placed for this crop"));
    }
}