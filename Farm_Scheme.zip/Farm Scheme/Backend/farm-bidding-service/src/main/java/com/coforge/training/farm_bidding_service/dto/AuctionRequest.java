package com.coforge.training.farm_bidding_service.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AuctionRequest {

    private Long cropId;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

}