package com.coforge.training.farm_bidding_service.controller;

import com.coforge.training.farm_bidding_service.dto.AuctionRequest;
import com.coforge.training.farm_bidding_service.entity.Auction;
import com.coforge.training.farm_bidding_service.repository.AuctionRepository;
import com.coforge.training.farm_bidding_service.service.AuctionService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auction")
@RequiredArgsConstructor
public class AuctionController {

    private final AuctionService auctionService;
    private final AuctionRepository auctionRepository;

    @PostMapping("/create")
    public Auction createAuction(@RequestBody Map<String, Long> request) {

        Long cropId = request.get("cropId");

        return auctionService.createAuction(cropId);
    }

    @GetMapping("/crop/{cropId}")
    public Auction getAuctionByCropId(@PathVariable Long cropId) {
        return auctionService.getAuctionByCropId(cropId);
    }

    @GetMapping("/active-count")
    public long getActiveAuctions() {
        return auctionRepository.countActiveAuctions();
    }

}