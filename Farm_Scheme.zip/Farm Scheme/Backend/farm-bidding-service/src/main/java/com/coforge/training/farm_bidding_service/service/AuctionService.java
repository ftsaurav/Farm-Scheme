package com.coforge.training.farm_bidding_service.service;

import com.coforge.training.farm_bidding_service.dto.AuctionRequest;
import com.coforge.training.farm_bidding_service.entity.Auction;
import com.coforge.training.farm_bidding_service.repository.AuctionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuctionService {

    private final AuctionRepository auctionRepository;

    public Auction createAuction(Long cropId) {

        Auction auction = new Auction();

        auction.setCropId(cropId);

        LocalDateTime now = LocalDateTime.now();

        auction.setStartTime(now);
        auction.setEndTime(now.plusMinutes(3));

        auction.setClosed(false);

        return auctionRepository.save(auction);

    }

    public Auction getAuctionByCropId(Long cropId) {

        return auctionRepository.findByCropIdAndClosedFalse(cropId)
                .orElseThrow(() -> new RuntimeException("Auction not found for this crop"));
    }

}
