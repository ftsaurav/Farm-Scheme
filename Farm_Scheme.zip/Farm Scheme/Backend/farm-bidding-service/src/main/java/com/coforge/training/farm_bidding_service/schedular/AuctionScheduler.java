package com.coforge.training.farm_bidding_service.schedular;

import com.coforge.training.farm_bidding_service.entity.Auction;
import com.coforge.training.farm_bidding_service.entity.Bid;
import com.coforge.training.farm_bidding_service.repository.AuctionRepository;
import com.coforge.training.farm_bidding_service.repository.BidRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

@Component
@RequiredArgsConstructor
public class AuctionScheduler {

    private final AuctionRepository auctionRepository;
    private final BidRepository bidRepository;

    @Scheduled(fixedRate = 60000)
    public void closeExpiredAuctions() {

        List<Auction> auctions = auctionRepository.findByClosedFalse();
        LocalDateTime now = LocalDateTime.now();

        for (Auction auction : auctions) {

            if (auction.getEndTime() != null && now.isAfter(auction.getEndTime())) {

                auction.setClosed(true);
                auctionRepository.save(auction);

                List<Bid> bids = bidRepository.findByCropId(auction.getCropId());

                if (!bids.isEmpty()) {

                    Bid highestBid = bids.stream()
                            .max(Comparator.comparing(Bid::getBidAmount))
                            .get();

                    for (Bid bid : bids) {

                        if (bid.getId().equals(highestBid.getId())) {
                            bid.setStatus("WON");
                        } else {
                            bid.setStatus("LOST");
                        }

                        bidRepository.save(bid);
                    }
                }
            }
        }
    }
}
