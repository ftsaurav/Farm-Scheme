package com.coforge.training.farm_bidding_service.controller;

import com.coforge.training.farm_bidding_service.repository.BidRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/bidder/dashboard")
@RequiredArgsConstructor
public class BidderDashboardController {

    private final BidRepository bidRepository;

    @GetMapping("/{bidderId}")
    public Map<String,Object> dashboard(@PathVariable Long bidderId){

        Map<String,Object> dashboard = new HashMap<>();

        dashboard.put("totalBids",
                bidRepository.countByBidderId(bidderId));

        dashboard.put("activeBids",
                bidRepository.countActiveBids(bidderId));

        dashboard.put("auctionsWon",
                bidRepository.countWonAuctions(bidderId));

        dashboard.put("totalSpent",
                bidRepository.totalSpent(bidderId));

        return dashboard;
    }
}