package com.coforge.training.farm_bidding_service.repository;

import com.coforge.training.farm_bidding_service.entity.Auction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface AuctionRepository extends JpaRepository<Auction, Long> {

    Optional<Auction> findByCropIdAndClosedFalse(Long cropId);

    @Query("SELECT COUNT(a) FROM Auction a WHERE a.closed = false")
    long countActiveAuctions();

    List<Auction> findByClosedFalse();

    long countByClosedFalse();


}
