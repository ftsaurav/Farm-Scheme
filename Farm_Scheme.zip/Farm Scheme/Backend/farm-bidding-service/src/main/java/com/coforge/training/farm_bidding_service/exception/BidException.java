package com.coforge.training.farm_bidding_service.exception;

public class BidException extends RuntimeException {

    public BidException(String message) {
        super(message);
    }

}