package com.coforge.training.farm_bidding_service.controller;

import com.coforge.training.farm_bidding_service.dto.BidRequest;
import com.coforge.training.farm_bidding_service.entity.Auction;
import com.coforge.training.farm_bidding_service.entity.Bid;
import com.coforge.training.farm_bidding_service.repository.AuctionRepository;
import com.coforge.training.farm_bidding_service.repository.BidRepository;
import com.coforge.training.farm_bidding_service.service.BidService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bids")
@RequiredArgsConstructor
public class BidController {

    private final BidService bidService;
    private final BidRepository bidRepository;
    private final AuctionRepository auctionRepository;

    @PostMapping("/place")
    public Bid placeBid(@RequestBody BidRequest request) {
        return bidService.placeBid(request);
    }

    @GetMapping("/crop/{cropId}")
    public List<Bid> getBids(@PathVariable Long cropId) {
        return bidService.getBids(cropId);
    }

    @GetMapping("/highest/{cropId}")
    public Bid getHighestBid(@PathVariable Long cropId) {
        return bidService.getHighestBid(cropId);
    }

    @GetMapping("/winner/{cropId}")
    public Bid getAuctionWinner(@PathVariable Long cropId) {
        return bidService.getAuctionWinner(cropId);
    }

    @GetMapping("/active-count")
    public long getActiveAuctions() {
        return auctionRepository.countByClosedFalse();
    }

}