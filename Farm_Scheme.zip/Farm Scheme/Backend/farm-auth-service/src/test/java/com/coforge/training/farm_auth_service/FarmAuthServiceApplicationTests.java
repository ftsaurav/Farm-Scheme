package com.coforge.training.farm_auth_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
