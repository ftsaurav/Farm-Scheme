package com.coforge.training.farm_auth_service.repository;

import com.coforge.training.farm_auth_service.entity.UserLandDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLandDetailsRepository extends JpaRepository<UserLandDetails, Long> {
}
