package com.coforge.training.farm_auth_service.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_bank_details")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserBankDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;
    private String ifscCode;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;
}