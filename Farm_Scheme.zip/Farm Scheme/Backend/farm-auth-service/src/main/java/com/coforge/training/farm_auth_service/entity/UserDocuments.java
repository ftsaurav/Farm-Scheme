package com.coforge.training.farm_auth_service.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_documents")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserDocuments {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String aadhaarNo;
    private String panNo;
    private String plotNumber;

    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;
}