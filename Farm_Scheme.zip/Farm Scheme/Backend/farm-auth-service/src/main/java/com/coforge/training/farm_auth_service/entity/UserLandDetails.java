package com.coforge.training.farm_auth_service.entity;

import com.coforge.training.farm_auth_service.entity.User;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_land_details")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLandDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double areaInHectares;

    private String landAddress;
    private String landPincode;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}