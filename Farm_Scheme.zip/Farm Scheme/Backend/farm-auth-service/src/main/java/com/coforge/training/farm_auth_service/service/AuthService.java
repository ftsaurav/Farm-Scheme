package com.coforge.training.farm_auth_service.service;

import com.coforge.training.farm_auth_service.dto.LoginRequest;
import com.coforge.training.farm_auth_service.dto.LoginResponse;
import com.coforge.training.farm_auth_service.dto.RegisterRequest;
import com.coforge.training.farm_auth_service.entity.*;
import com.coforge.training.farm_auth_service.repository.*;
import com.coforge.training.farm_auth_service.security.JwtService;
import com.coforge.training.farm_auth_service.security.JwtUtil;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final UserAddressRepository addressRepository;
    private final UserLandDetailsRepository landRepository;
    private final UserBankDetailsRepository bankRepository;
    private final UserDocumentsRepository documentsRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private  final JwtService jwtService;

    @Transactional
    public String registerUser(RegisterRequest request) {

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            throw new RuntimeException("Email already exists");
        }

        // 🔹 1️⃣ Save User
        User user = userRepository.save(
                User.builder()
                        .fullName(request.getFullName())
                        .email(request.getEmail())
                        .contactNumber(request.getContactNo())
                        .password(passwordEncoder.encode(request.getPassword()))
                        .role(Role.valueOf(request.getUserType().toUpperCase()))
                        .build()
        );

        // 🔹 2️⃣ Save Address
        addressRepository.save(
                UserAddress.builder()
                        .addressLine1(request.getAddressLine1())
                        .addressLine2(request.getAddressLine2())
                        .city(request.getCity())
                        .state(request.getState())
                        .pincode(request.getPincode())
                        .user(user)
                        .build()
        );

        // 🔹 3️⃣ Save Land (Farmer only)
        if ("FARMER".equalsIgnoreCase(request.getUserType())) {

            landRepository.save(
                    UserLandDetails.builder()
                            .areaInHectares(request.getLandArea())
                            .landAddress(request.getLandAddress())
                            .landPincode(request.getLandPincode())
                            .user(user)
                            .build()
            );
        }

        // 🔹 4️⃣ Save Bank
        bankRepository.save(
                UserBankDetails.builder()
                        .accountNumber(request.getAccountNo())
                        .ifscCode(request.getIfscCode())
                        .user(user)
                        .build()
        );

        // 🔹 5️⃣ Save Documents (numbers only now)

        documentsRepository.save(
                UserDocuments.builder()
                        .aadhaarNo(request.getAadhaarNo())
                        .panNo(request.getPanNo())
                        .plotNumber(request.getPlotNumber())
                        .user(user)
                        .build()
        );

        return "User Registered Successfully";
    }

    public LoginResponse login(LoginRequest request) {

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }

        String token = jwtService.generateToken(
                user.getEmail(),
                user.getRole().name()
        );

        return LoginResponse.builder()
                .id(user.getId())
                .email(user.getEmail())
                .name(user.getFullName())   // since you renamed it
                .role(user.getRole().name().toLowerCase())
                .token(token)
                .build();
    }
}