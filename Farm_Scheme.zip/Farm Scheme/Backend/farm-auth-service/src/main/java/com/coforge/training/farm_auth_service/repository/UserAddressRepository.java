package com.coforge.training.farm_auth_service.repository;

import com.coforge.training.farm_auth_service.entity.UserAddress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserAddressRepository extends JpaRepository<UserAddress, Long> {
}
