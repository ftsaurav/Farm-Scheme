package com.coforge.training.farm_auth_service.repository;

import com.coforge.training.farm_auth_service.entity.UserBankDetails;
import com.coforge.training.farm_auth_service.entity.UserLandDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserBankDetailsRepository extends JpaRepository<UserBankDetails, Long> {
}
