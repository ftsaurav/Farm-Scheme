package com.coforge.training.farm_auth_service.config;

import com.coforge.training.farm_auth_service.entity.Role;
import com.coforge.training.farm_auth_service.entity.User;
import com.coforge.training.farm_auth_service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Configuration
@RequiredArgsConstructor
public class AdminInitializer {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Bean
    CommandLineRunner createAdmin() {
        return args -> {

            if (userRepository.findByEmail("admin@farm.com").isEmpty()) {

                User admin = User.builder()
                        .fullName("System Admin")
                        .email("admin@farm.com")
                        .password(passwordEncoder.encode("admin123"))
                        .role(Role.ADMIN)
                        .contactNumber("9999999999")
                        .build();

                userRepository.save(admin);
            }

        };
    }
}