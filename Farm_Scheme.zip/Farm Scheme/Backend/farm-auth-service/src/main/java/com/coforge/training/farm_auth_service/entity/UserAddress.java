package com.coforge.training.farm_auth_service.entity;

import com.coforge.training.farm_auth_service.entity.User;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "user_address")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserAddress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String pincode;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
}