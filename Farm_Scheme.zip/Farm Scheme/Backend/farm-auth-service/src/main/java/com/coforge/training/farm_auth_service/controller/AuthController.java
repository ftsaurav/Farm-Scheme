package com.coforge.training.farm_auth_service.controller;

import com.coforge.training.farm_auth_service.dto.LoginRequest;
import com.coforge.training.farm_auth_service.dto.LoginResponse;
import com.coforge.training.farm_auth_service.dto.RegisterRequest;
import com.coforge.training.farm_auth_service.entity.User;
import com.coforge.training.farm_auth_service.repository.UserRepository;
import com.coforge.training.farm_auth_service.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final UserRepository userRepository;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {

        return ResponseEntity.ok(authService.registerUser(request));
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @GetMapping("/users/{id}")
    public String getUserById(@PathVariable Long id) {
        User user= userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return user.getFullName();
    }
}