package com.coforge.training.farm_auth_service.entity;

public enum Role {
    ADMIN,
    FARMER,
    BIDDER
}