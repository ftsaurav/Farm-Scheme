package com.coforge.training.farm_auth_service.controller;

import com.coforge.training.farm_auth_service.entity.Role;
import com.coforge.training.farm_auth_service.entity.User;
import com.coforge.training.farm_auth_service.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;

    @GetMapping("/farmers")
    public List<User> getFarmers() {
        return userRepository.findByRole(Role.FARMER);
    }

    @GetMapping("/bidders")
    public List<User> getBidders() {
        return userRepository.findByRole(Role.BIDDER);
    }

}
