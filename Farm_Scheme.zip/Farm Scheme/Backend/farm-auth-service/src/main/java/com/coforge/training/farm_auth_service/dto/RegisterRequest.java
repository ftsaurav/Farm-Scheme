package com.coforge.training.farm_auth_service.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class RegisterRequest {

    // ================= BASIC =================

    @NotBlank
    private String fullName;

    @Email
    @NotBlank
    private String email;

    @Size(min = 6)
    private String password;

    @NotBlank
    private String contactNo;

    @NotBlank
    private String userType;   // FARMER | BIDDER

    // ================= ADDRESS =================

    @NotBlank
    private String addressLine1;

    private String addressLine2;

    @NotBlank
    private String city;

    @NotBlank
    private String state;

    @NotBlank
    private String pincode;

    // ================= BANK =================

    @NotBlank
    private String accountNo;

    @NotBlank
    private String ifscCode;

    // ================= DOCUMENT DETAILS =================

    @NotBlank
    private String aadhaarNo;

    @NotBlank
    private String panNo;

    private String plotNumber;

    // ================= LAND (Farmer Only) =================

    private Double landArea;
    private String landAddress;
    private String landPincode;
}