package com.coforge.training.farm_auth_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmAuthServiceApplication.class, args);
	}

}
