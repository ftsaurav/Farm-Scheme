package com.coforge.training.farm_api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
