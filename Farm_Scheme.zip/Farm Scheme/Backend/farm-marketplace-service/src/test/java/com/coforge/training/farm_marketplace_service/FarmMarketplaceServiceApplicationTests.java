package com.coforge.training.farm_marketplace_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmMarketplaceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
