package com.coforge.training.farm_marketplace_service.service;

import com.coforge.training.farm_marketplace_service.entity.SoldCrop;
import com.coforge.training.farm_marketplace_service.repository.SoldCropRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class FarmerService {
    private final SoldCropRepository soldCropRepository;
    public List<SoldCrop> getSoldHistory(Long farmerId) {

        return soldCropRepository.findByFarmerId(farmerId);
    }
}
