package com.coforge.training.farm_marketplace_service.client;

import com.coforge.training.farm_marketplace_service.dto.UserDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "FARM-AUTH-SERVICE")
public interface AuthClient {

    @GetMapping("/api/admin/farmers")
    List<UserDTO> getAllFarmers();

    @GetMapping("/api/admin/bidders")
    List<UserDTO> getAllBidders();

}