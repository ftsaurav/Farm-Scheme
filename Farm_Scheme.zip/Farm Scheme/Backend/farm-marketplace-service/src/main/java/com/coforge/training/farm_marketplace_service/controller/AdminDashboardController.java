package com.coforge.training.farm_marketplace_service.controller;

import com.coforge.training.farm_marketplace_service.client.AuthClient;
import com.coforge.training.farm_marketplace_service.client.BidClient;
import com.coforge.training.farm_marketplace_service.client.InsuranceClient;
import com.coforge.training.farm_marketplace_service.repository.CropRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/dashboard")
@RequiredArgsConstructor
public class AdminDashboardController {

    private final AuthClient authClient;
    private final CropRepository cropRepository;
    private final BidClient bidClient;
    private final InsuranceClient insuranceClient;

    @GetMapping
    public Map<String, Object> getAdminDashboard() {

        Map<String, Object> dashboard = new HashMap<>();

        dashboard.put("totalFarmers", authClient.getAllFarmers().size());
        dashboard.put("totalBidders", authClient.getAllBidders().size());

        dashboard.put("totalCrops", cropRepository.count());
        dashboard.put("pendingCrops", cropRepository.countByStatus("PENDING"));

        dashboard.put("activeAuctions", bidClient.getActiveAuctions());

        dashboard.put("insurancePolicies", insuranceClient.totalPolicies());
        dashboard.put("pendingClaims", insuranceClient.pendingClaims());

        return dashboard;
    }
}
