package com.coforge.training.farm_marketplace_service.service;

import com.coforge.training.farm_marketplace_service.client.BidClient;
import com.coforge.training.farm_marketplace_service.dto.Bid;
import com.coforge.training.farm_marketplace_service.entity.Crop;
import com.coforge.training.farm_marketplace_service.entity.SoldCrop;
import com.coforge.training.farm_marketplace_service.repository.CropRepository;
import com.coforge.training.farm_marketplace_service.repository.SoldCropRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AdminService {

    private final SoldCropRepository soldCropRepository;
    private final CropRepository cropRepository;
    private final BidClient bidClient;

    public SoldCrop finalizeAuction(Long cropId) {

        Bid winner = bidClient.getAuctionWinner(cropId);

        Crop crop = cropRepository.findById(cropId)
                .orElseThrow(() -> new RuntimeException("Crop not found"));

        SoldCrop soldCrop = SoldCrop.builder()
                .cropId(cropId)
                .farmerId(crop.getFarmerId())
                .bidderId(winner.getBidderId())
                .soldPrice(winner.getBidAmount())
                .quantity(crop.getQuantity())
                .soldDate(LocalDateTime.now())
                .build();

        return soldCropRepository.save(soldCrop);
    }
}