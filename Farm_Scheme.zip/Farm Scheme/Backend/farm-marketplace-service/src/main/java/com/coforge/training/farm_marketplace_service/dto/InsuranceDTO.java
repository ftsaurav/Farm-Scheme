package com.coforge.training.farm_marketplace_service.dto;

import lombok.Data;

@Data
public class InsuranceDTO {

    private Long id;
    private Long farmerId;
    private Long cropId;
    private Double cropValue;
    private Double premiumAmount;
    private String status;

}