package com.coforge.training.farm_marketplace_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Crop {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long farmerId;

    private String cropType;

    private String cropName;

    private String fertilizerType;

    private Double quantity;

    private Double basePrice;

    private String status;
    // PENDING / APPROVED / SOLD

    private LocalDateTime createdAt;

}