package com.coforge.training.farm_marketplace_service.dto;

import lombok.Data;

@Data
public class CropRequest {

    private Long farmerId;
    private String cropType;
    private String cropName;
    private String fertilizerType;
    private Double quantity;
    private Double basePrice;

}