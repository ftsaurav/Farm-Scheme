package com.coforge.training.farm_marketplace_service.controller;

import com.coforge.training.farm_marketplace_service.client.AuthClient;
import com.coforge.training.farm_marketplace_service.dto.UserDTO;
import com.coforge.training.farm_marketplace_service.entity.Crop;
import com.coforge.training.farm_marketplace_service.entity.SoldCrop;
import com.coforge.training.farm_marketplace_service.repository.CropRepository;
import com.coforge.training.farm_marketplace_service.service.AdminService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final CropRepository cropRepository;
    private final AuthClient authClient;
    private final AdminService adminService;

    @GetMapping("/crops/pending")
    public List<Crop> getPendingCrops() {
        return cropRepository.findByStatus("PENDING");
    }

    @PutMapping("/crops/{id}/approve")
    public Crop approveCrop(@PathVariable Long id) {

        Crop crop = cropRepository.findById(id).orElseThrow();

        crop.setStatus("APPROVED");

        return cropRepository.save(crop);
    }

    @GetMapping("/farmers")
    public List<UserDTO> getFarmers() {
        return authClient.getAllFarmers();
    }

    @GetMapping("/bidders")
    public List<UserDTO> getBidders() {
        return authClient.getAllBidders();
    }

    @PostMapping("/auction/finalize/{cropId}")
    public SoldCrop finalizeAuction(@PathVariable Long cropId) {
        return adminService.finalizeAuction(cropId);
    }

}