package com.coforge.training.farm_marketplace_service.repository;

import com.coforge.training.farm_marketplace_service.entity.Crop;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CropRepository extends JpaRepository<Crop, Long> {
    List<Crop> findByStatus(String status);

    long countByStatus(String status);

    long countByFarmerId(Long farmerId);

    long countByFarmerIdAndStatus(Long farmerId, String status);
}