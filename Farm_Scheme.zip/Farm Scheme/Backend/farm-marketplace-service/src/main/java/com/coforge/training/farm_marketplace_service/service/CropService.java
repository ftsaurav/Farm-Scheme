package com.coforge.training.farm_marketplace_service.service;

import com.coforge.training.farm_marketplace_service.dto.CropRequest;
import com.coforge.training.farm_marketplace_service.entity.Crop;
import com.coforge.training.farm_marketplace_service.repository.CropRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CropService {

    private final CropRepository cropRepository;

    public Crop placeSellRequest(CropRequest request) {

        Crop crop = Crop.builder()
                .farmerId(request.getFarmerId())
                .cropType(request.getCropType())
                .cropName(request.getCropName())
                .fertilizerType(request.getFertilizerType())
                .quantity(request.getQuantity())
                .basePrice(request.getBasePrice())
                .status("PENDING")
                .createdAt(LocalDateTime.now())
                .build();

        return cropRepository.save(crop);
    }

    public List<Crop> getMarketplaceCrops() {
        return cropRepository.findByStatus("APPROVED");
    }
}