package com.coforge.training.farm_marketplace_service.client;

import com.coforge.training.farm_marketplace_service.dto.Bid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "FARM-BIDDING-SERVICE")
public interface BidClient {

    @GetMapping("/api/bids/winner/{cropId}")
    Bid getAuctionWinner(@PathVariable Long cropId);

    @GetMapping("/api/bids/active-count")
    long getActiveAuctions();

}