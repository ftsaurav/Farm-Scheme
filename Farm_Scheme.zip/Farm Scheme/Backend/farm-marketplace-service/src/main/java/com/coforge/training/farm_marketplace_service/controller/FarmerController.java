package com.coforge.training.farm_marketplace_service.controller;

import com.coforge.training.farm_marketplace_service.entity.SoldCrop;
import com.coforge.training.farm_marketplace_service.service.FarmerService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/farmers")
@AllArgsConstructor
public class FarmerController {

    public final FarmerService farmerService;

    @GetMapping("/sold-history/{farmerId}")
    public List<SoldCrop> getSoldHistory(@PathVariable Long farmerId) {
        return farmerService.getSoldHistory(farmerId);
    }
}