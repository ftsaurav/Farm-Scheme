package com.coforge.training.farm_marketplace_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class FarmMarketplaceServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FarmMarketplaceServiceApplication.class, args);
    }

}