package com.coforge.training.farm_marketplace_service.repository;

import com.coforge.training.farm_marketplace_service.entity.SoldCrop;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SoldCropRepository extends JpaRepository<SoldCrop, Long> {

    List<SoldCrop> findByFarmerId(Long farmerId);

    long countByFarmerId(Long farmerId);

    @Query("SELECT COALESCE(SUM(s.soldPrice),0) FROM SoldCrop s WHERE s.farmerId = :farmerId")
    Double totalEarnings(Long farmerId);
}
