package com.coforge.training.farm_marketplace_service.controller;

import com.coforge.training.farm_marketplace_service.client.InsuranceClient;
import com.coforge.training.farm_marketplace_service.repository.CropRepository;
import com.coforge.training.farm_marketplace_service.repository.SoldCropRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/farmer/dashboard")
@RequiredArgsConstructor
public class FarmerDashboardController {

    private final CropRepository cropRepository;
    private final SoldCropRepository soldCropRepository;
    private final InsuranceClient insuranceClient;

    @GetMapping("/{farmerId}")
    public Map<String, Object> farmerDashboard(@PathVariable Long farmerId) {

        Map<String, Object> dashboard = new HashMap<>();

        dashboard.put("totalCrops",
                cropRepository.countByFarmerId(farmerId));

        dashboard.put("pendingCrops",
                cropRepository.countByFarmerIdAndStatus(farmerId,"PENDING"));

        dashboard.put("approvedCrops",
                cropRepository.countByFarmerIdAndStatus(farmerId,"APPROVED"));

        dashboard.put("soldCrops",
                soldCropRepository.countByFarmerId(farmerId));

        dashboard.put("totalEarnings",
                soldCropRepository.totalEarnings(farmerId));

        dashboard.put("insurancePolicies",
                insuranceClient.getPolicies(farmerId));

        return dashboard;
    }
}