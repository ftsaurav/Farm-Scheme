package com.coforge.training.farm_marketplace_service.dto;

import lombok.Data;

@Data
public class Bid {

    private Long id;
    private Long cropId;
    private Long bidderId;
    private Double bidAmount;

}