package com.coforge.training.farm_marketplace_service.client;

import com.coforge.training.farm_marketplace_service.dto.InsuranceDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "FARM-INSURANCE-SERVICE")
public interface InsuranceClient {

    @GetMapping("/api/insurance/farmer/{farmerId}")
    List<InsuranceDTO> getPolicies(@PathVariable Long farmerId);

    @GetMapping("/api/insurance/admin/pending-claims")
    long pendingClaims();

    @GetMapping("/api/insurance/count")
    long totalPolicies();

}