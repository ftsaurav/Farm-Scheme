package com.coforge.training.farm_marketplace_service.controller;

import com.coforge.training.farm_marketplace_service.dto.CropRequest;
import com.coforge.training.farm_marketplace_service.entity.Crop;
import com.coforge.training.farm_marketplace_service.service.CropService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/crops")
@RequiredArgsConstructor
public class CropController {

    private final CropService cropService;

    @PostMapping("/request-sell")
    public Crop requestSell(@RequestBody CropRequest request) {
        return cropService.placeSellRequest(request);
    }

    @GetMapping("/marketplace")
    public List<Crop> getMarketplace() {
        return cropService.getMarketplaceCrops();
    }
}