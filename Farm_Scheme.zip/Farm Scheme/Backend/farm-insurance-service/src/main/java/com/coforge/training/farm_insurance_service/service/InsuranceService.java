package com.coforge.training.farm_insurance_service.service;

import com.coforge.training.farm_insurance_service.dto.ClaimRequest;
import com.coforge.training.farm_insurance_service.dto.InsuranceRequest;
import com.coforge.training.farm_insurance_service.entity.Insurance;
import com.coforge.training.farm_insurance_service.repository.InsuranceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class InsuranceService {

    private final InsuranceRepository insuranceRepository;

    public Insurance applyInsurance(InsuranceRequest request) {

        double rate;

        // Premium calculation based on season
        switch (request.getSeason().toUpperCase()) {
            case "KHARIF":
                rate = 0.02;
                break;
            case "RABI":
                rate = 0.015;
                break;
            default:
                rate = 0.05;
        }

        double premium = request.getSumInsured() * rate;

        Insurance insurance = Insurance.builder()
                .farmerId(request.getFarmerId())
                .cropId(request.getCropId())
                .cropValue(request.getCropValue())
                .season(request.getSeason())
                .year(request.getYear())
                .area(request.getArea())
                .sumInsured(request.getSumInsured())
                .premiumAmount(premium)
                .status("APPLIED")
                .build();

        return insuranceRepository.save(insurance);
    }

    public List<Insurance> getFarmerPolicies(Long farmerId) {
        return insuranceRepository.findByFarmerId(farmerId);
    }

    public Insurance claimInsurance(ClaimRequest request) {

        Insurance insurance = insuranceRepository.findById(request.getPolicyId())
                .orElseThrow(() -> new RuntimeException("Insurance not found"));

        // Only approved policies can request claim
        if (!"APPROVED".equalsIgnoreCase(insurance.getStatus())) {
            throw new RuntimeException("Insurance claim can only be requested after admin approval");
        }

        insurance.setClaimReason(request.getCauseOfLoss());
        insurance.setClaimAmount(request.getClaimAmount());
        insurance.setDateOfLoss(request.getDateOfLoss());
        insurance.setStatus("CLAIM_REQUESTED");

        return insuranceRepository.save(insurance);
    }

    public Insurance approvePolicy(Long insuranceId) {

        Insurance insurance = insuranceRepository.findById(insuranceId)
                .orElseThrow(() -> new RuntimeException("Insurance not found"));

        insurance.setStatus("APPROVED");

        return insuranceRepository.save(insurance);
    }

    public Insurance rejectPolicy(Long insuranceId) {

        Insurance insurance = insuranceRepository.findById(insuranceId)
                .orElseThrow(() -> new RuntimeException("Insurance not found"));

        insurance.setStatus("REJECTED");

        return insuranceRepository.save(insurance);
    }

    public Insurance approveClaim(Long insuranceId) {

        Insurance insurance = insuranceRepository.findById(insuranceId)
                .orElseThrow(() -> new RuntimeException("Insurance not found"));

        insurance.setStatus("CLAIM_APPROVED");

        return insuranceRepository.save(insurance);
    }

    public Insurance rejectClaim(Long insuranceId) {

        Insurance insurance = insuranceRepository.findById(insuranceId)
                .orElseThrow(() -> new RuntimeException("Insurance not found"));

        insurance.setStatus("CLAIM_REJECTED");

        return insuranceRepository.save(insurance);
    }
    public long totalPolicies() {
        return insuranceRepository.count();
    }

    public long pendingClaims() {
        return insuranceRepository.countByStatus("CLAIM_REQUESTED");
    }

    public List<Insurance> getAppliedPolicies() {
        return insuranceRepository.findByStatus("APPLIED");
    }

    public List<Insurance> getClaimRequests() {
        return insuranceRepository.findByStatus("CLAIM_REQUESTED");
    }
}