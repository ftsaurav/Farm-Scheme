package com.coforge.training.farm_insurance_service.repository;

import com.coforge.training.farm_insurance_service.entity.Insurance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InsuranceRepository extends JpaRepository<Insurance, Long> {

    // Get all policies for a farmer
    List<Insurance> findByFarmerId(Long farmerId);

    // Count policies by status (APPLIED, APPROVED, REJECTED, CLAIMED)
    long countByStatus(String status);

    // Find policies by farmer and status
    List<Insurance> findByFarmerIdAndStatus(Long farmerId, String status);

    // Get policies for a crop
    List<Insurance> findByCropId(Long cropId);

    List<Insurance> findByStatus(String status);

}