package com.coforge.training.farm_insurance_service.dto;

import lombok.Data;

@Data
public class InsuranceRequest {

    private Long farmerId;

    private Long cropId;

    private String season;      // KHARIF / RABI / COMMERCIAL

    private Integer year;       // e.g., 2026

    private Double area;        // land area in hectares

    private Double sumInsured;  // insurance amount

    private Double cropValue;   // total crop value

}