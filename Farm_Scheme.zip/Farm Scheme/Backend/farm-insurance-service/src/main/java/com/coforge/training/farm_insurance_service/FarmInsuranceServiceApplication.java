package com.coforge.training.farm_insurance_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmInsuranceServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmInsuranceServiceApplication.class, args);
	}

}
