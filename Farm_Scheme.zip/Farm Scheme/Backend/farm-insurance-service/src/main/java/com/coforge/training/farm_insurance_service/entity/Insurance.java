package com.coforge.training.farm_insurance_service.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Insurance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Farmer & Crop
    private Long farmerId;

    private Long cropId;

    private Double cropValue;

    // Insurance details
    private String season;        // KHARIF / RABI / COMMERCIAL

    private Integer year;

    private Double area;          // land area in hectares

    private Double sumInsured;

    private Double premiumAmount;

    private String insuranceCompany;

    private String status;
    // APPLIED
    // APPROVED
    // REJECTED
    // CLAIMED

    // Claim details
    private String claimReason;

    private Double claimAmount;

    private LocalDate dateOfLoss;

}