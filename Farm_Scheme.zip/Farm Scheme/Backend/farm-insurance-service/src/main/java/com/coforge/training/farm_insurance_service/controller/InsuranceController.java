package com.coforge.training.farm_insurance_service.controller;

import com.coforge.training.farm_insurance_service.dto.ClaimRequest;
import com.coforge.training.farm_insurance_service.dto.InsuranceRequest;
import com.coforge.training.farm_insurance_service.entity.Insurance;
import com.coforge.training.farm_insurance_service.repository.InsuranceRepository;
import com.coforge.training.farm_insurance_service.service.InsuranceService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/insurance")
@RequiredArgsConstructor
public class InsuranceController {

    private final InsuranceService insuranceService;
    private final InsuranceRepository insuranceRepository;

    // Apply insurance policy
    @PostMapping("/apply")
    public Insurance applyInsurance(@RequestBody InsuranceRequest request) {
        return insuranceService.applyInsurance(request);
    }

    // Get all policies of a farmer
    @GetMapping("/farmer/{farmerId}")
    public List<Insurance> getFarmerPolicies(@PathVariable Long farmerId) {
        return insuranceService.getFarmerPolicies(farmerId);
    }

    // Claim insurance
    @PostMapping("/claim")
    public Insurance claimInsurance(@RequestBody ClaimRequest request) {
        return insuranceService.claimInsurance(request);
    }

    // Admin approves insurance policy
    @PutMapping("/admin/approve-policy/{id}")
    public Insurance approvePolicy(@PathVariable Long id) {
        return insuranceService.approvePolicy(id);
    }

    // Admin rejects insurance policy
    @PutMapping("/admin/reject-policy/{id}")
    public Insurance rejectPolicy(@PathVariable Long id) {
        return insuranceService.rejectPolicy(id);
    }

    // Admin approves claim
    @PutMapping("/admin/approve-claim/{id}")
    public Insurance approveClaim(@PathVariable Long id) {
        return insuranceService.approveClaim(id);
    }

    // Admin rejects claim
    @PutMapping("/admin/reject-claim/{id}")
    public Insurance rejectClaim(@PathVariable Long id) {
        return insuranceService.rejectClaim(id);
    }

    // Admin dashboard - total policies
    @GetMapping("/admin/total-policies")
    public long totalPolicies() {
        return insuranceService.totalPolicies();
    }

    // Admin dashboard - pending claims
    @GetMapping("/admin/pending-claims")
    public long pendingClaims() {
        return insuranceService.pendingClaims();
    }

    @GetMapping("/admin/applied-policies")
    public List<Insurance> getAppliedPolicies() {
        return insuranceService.getAppliedPolicies();
    }

    @GetMapping("/admin/claim-requests")
    public List<Insurance> getClaimRequests() {
        return insuranceService.getClaimRequests();
    }

    @GetMapping("/count")
    public long totalPolicie() {
        return insuranceRepository.count();
    }
}