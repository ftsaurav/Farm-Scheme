package com.coforge.training.farm_insurance_service.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ClaimRequest {

    private Long policyId;          // insurance policy id

    private Long farmerId;

    private String insuranceCompany;

    private String causeOfLoss;     // flood, pest attack, drought etc.

    private LocalDate dateOfLoss;

    private Double claimAmount;
}